/*
* name;
*/
class GameCrypto{
    public GAME_AES_KEY:string = null;
    
    constructor(){

    }

    AesDecrypt(a,b=null,c=null){ return a;}
}