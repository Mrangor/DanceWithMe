/*
* name;
*/

class HttpConn{
    public url:string = null;
    public timeout:number = 0;
    public responseType:string = null;    
    private complete:Function = null;
    private progress:Function = null
    private error:Function = null;

    constructor(fn:Function){
        this.complete = fn;
    }

    send(){
        let xhr = new Laya.HttpRequest();
        xhr.http.timeout = this.timeout;
        xhr.once(Laya.Event.COMPLETE, this, this.handleComplete);
        xhr.once(Laya.Event.ERROR, this, this.handleError);
        xhr.on(Laya.Event.PROGRESS, this, this.handleProcess);
        xhr.send(this.url,'','get',this.responseType);
    }

    public onComplete(handler:Function){
        this.complete = handler;
        return this;
    }

    public onError(handler:Function){
        this.error = handler;
        return this;
    }

    public onProgress(handler:Function){
        this.progress = handler;
        return this;
    }

    private handleComplete(data){
        if(this.complete){
            data = JSON.parse(data);
            this.complete(data);
        }
    }
    private handleError(data){
        console.log(data);
        if(this.error){
            this.error(data);
        }
        else{
            setTimeout(function() {
                this.send();
            }.bind(this), 3000);
        }
    }
    private handleProcess(data){
        if(this.progress){
            this.progress(data);
        }
    }
}

class HTTP{
    private url:string = null;
    private timeout:number = 0;
    private responseType:string = null;
    public mid:number = 0;
    public token:string = null;
    constructor(url:string,responseType:string='text',timeout:number = 3000){
        this.url = url;
        this.timeout = timeout;
        this.responseType = responseType;
    }

    make(path:string,data:any,completeHandler:Function = null):HttpConn{
        if(data == null){
            data = {};
        }

        if(this.mid){
            this.mid++;
            data.mid = this.mid;
        }

        if(this.token){
            data.token = this.token;    
        }

        let sendtext = '?';
        for (let k in data) {
            if (sendtext != "?") {
                sendtext += "&";
            }
            sendtext += (k + "=" + data[k]);
        }

        var item = new HttpConn(completeHandler);
        item.url = this.url + path + encodeURI(sendtext);
        item.timeout = this.timeout;
        item.responseType = this.responseType;
        return item;
    }

    send(path:string,data:any,completeHandler:Function = null){
        var conn = this.make(path,data,completeHandler);
        conn.send();
    }
    
}