/*
* name;
*/
interface NetHandler{
    onMessage(event,data)
    onConnected()
    onClose()
    onError()
}