/*
* name;
*/
class EmptyCrypto{
    encode(source){ return source; }
    decode(source){ return source; }
}