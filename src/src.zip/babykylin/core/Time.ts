/*
* name;
*/
class Time{
    public static time:number = 0;
    public static deltaTime = 0;
    public static frameCount:number = 0;
}