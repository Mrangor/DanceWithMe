/**
 * 场景主逻辑模板，切换场景时实例化；可用于当前场景网络模块注册
 */
class Master {
    public setting: MasterInfo;
    protected agent: NetAgent;

    enter(params) { }
    update() { }
    exit() { }
    isPlaying() { }
}

