/*
* name;
*/
class AppSettings{
    public designWidth:number;
    public designHeight:number;
    public scaleMode:string;
    public screenMode:string;
    public frameRate:string;
    public showStats:boolean;
    public statsX:number = 0;
    public statsY:number = 0;

    public maxUILayer:number;
    public alertWidget:any;
    public wcWidget:any;
}