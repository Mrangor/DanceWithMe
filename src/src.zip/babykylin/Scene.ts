/**
 * 场景基类
 */
class Scene {
    private _isGameScene = false;
    private _designWidth = -1;
    private _designHeight = -1;

    constructor(designWidth, designHeight, isGameScene = false) {
        this._designWidth = designWidth;
        this._designHeight = designHeight;
        this._isGameScene = isGameScene;
    }

    public get isGameScene() {
        return this._isGameScene;
    }

    getDesignResolution(): Laya.Point {
        if (this._designHeight < 0 || this._designWidth < 0) {
            return null;
        }
        return new Laya.Point(this._designWidth, this._designHeight);
    }

    getRes() {

    }

    start() {

    }

    update() {

    }

    end() {
    }
}