/*
* name;
*/
class UIMgr {
    private static _inst: UIMgr = null;
    public static get inst(): UIMgr {
        if (UIMgr._inst == null) {
            UIMgr._inst = new UIMgr();
        }
        return UIMgr._inst;
    }

    public static alertClass: any;
    public static wcClass: any;

    private _layers: Array<fairygui.GComponent> = null;//初始化所有UI层级根节点，对应UI挂载到对应根节点上
    getLayer(layer: number): fairygui.GComponent {
        if (layer >= 0 && layer < this._layers.length) {
            return this._layers[layer];
        }
        return null;
    }

    configure(maxUILayer: number, alertClass: any, wcClass: any) {
        UIMgr.alertClass = alertClass;
        UIMgr.wcClass = wcClass;

        Laya.stage.addChild(fairygui.GRoot.inst.displayObject);

        //init layers of ui.
        this._layers = new Array<fairygui.GComponent>();
        for (let i = 0; i < maxUILayer; ++i) {
            let uiLayer = new fairygui.GComponent();
            uiLayer.setSize(fairygui.GRoot.inst.width, fairygui.GRoot.inst.height);
            fairygui.GRoot.inst.addChild(uiLayer);
            this._layers.push(uiLayer);
        }

        //handle resize event. keep the size of uilayers as the same as stage.
        Laya.stage.on(Laya.Event.RESIZE, this, () => {
            for (let i = 0; i < this._layers.length; ++i) {
                let uiLayer = this._layers[i];
                uiLayer.setSize(fairygui.GRoot.inst.width, fairygui.GRoot.inst.height);
            }
        });
    }

    setLayerMask(layer: number, packageName: string, compName: string) {
        var uiLayer = this._layers[layer];
        var comp = fairygui.UIPackage.createObject(packageName, compName).asCom;
        comp.addRelation(uiLayer, fairygui.RelationType.Size);
        uiLayer.addChildAt(comp, 0);
    }

    add(classOfWidget: any, parent: Widget = null): Widget {
        var w = new classOfWidget as Widget;
        if (!parent) {
            w.create(this.getLayer(w.layer));
        }
        else {
            w.create(parent.view);
        }
        return w;
    }

    clear() {
        Widget.clearPool();
    }
    /**
     * 
     * @param classOfWidget 挂件类
     * @param maskAlpha 添加mask遮罩
     */
    popup(classOfWidget: any, maskAlpha: number = 0.6) {
        let mask: fairygui.GComponent = null;
        if (maskAlpha >= 0) {
            let comp = fairygui.UIPackage.createObject('Basic', 'LayerMask').asCom;
            comp.getChild('mask').asGraph.alpha = maskAlpha;
            mask = comp;
            mask.data = '#LayerMask'
        }
        var w = new classOfWidget as Widget;
        if (!mask) {
            w.create(this.getLayer(w.layer));
        }
        else {
            var uiLayer = this.getLayer(w.layer);
            mask.addRelation(uiLayer, fairygui.RelationType.Size);
            mask.width = uiLayer.width;
            mask.height = uiLayer.height;
            uiLayer.addChild(mask);
            w.create(mask);
        }
        return w;
    }
}