/*
* 页面基类，继承挂件
*/
class Page extends Widget {
    constructor(pkg, comp, layer) {
        super(pkg, comp, layer);
        this.keepSize();
    }
}