/*
* 挂件：所有弹窗的基类
*/
class Widget {
    private static _pool: Array<Widget> = new Array<Widget>();
    private _relations: Array<number> = new Array<number>();
    private _component: string = null;
    private _package: string = null;
    private _timer: number = -1;

    protected _view: fairygui.GComponent = null;//挂件实例对象
    protected _layer: number = 0;

    /**
     * 
     * @param pkg   FairyGUI包名
     * @param comp  FairyGUI组件名
     * @param layer UI层级
     */
    constructor(pkg, comp, layer) {
        this._package = pkg;
        this._component = comp;

        Widget._pool.push(this);
    }

    public static clearPool() {
        while (Widget._pool.length) {
            let w = Widget._pool[0];
            w.hide();
        }
    }

    public hide() {
        var root = this._view;
        if (!root || !root.parent) {
            return;
        }
        //如果是MASK，则需要移除
        if (root.parent.data) {
            root = root.parent;
        }

        if (root.parent) {
            root.removeFromParent();
        }
        if (root) {
            root.dispose();
        }

        var idx = Widget._pool.indexOf(this);
        Widget._pool.splice(idx, 1);
        this.onDispose();
        clearInterval(this._timer);
    }

    get package(): string {
        return this._package;
    }
    get component(): string {
        return this._component;
    }

    get view() {
        return this._view;
    }

    get layer() {
        return this._layer;
    }

    protected keepSize() {
        this.addRelation(fairygui.RelationType.Size);
    }

    protected keepCenter() {
        this.addRelation(fairygui.RelationType.Center_Center);
        this.addRelation(fairygui.RelationType.Middle_Middle);
    }

    protected addRelation(relationType: number) {
        this._relations.push(relationType);
    }

    create(parent: fairygui.GComponent) {
        //通过当前的挂件包名和组件名，构造fairygui对象
        let obj = fairygui.UIPackage.createObject(this._package, this._component);
        let view = obj.asCom;
        this._view = view;
        //设置挂件位置关系
        for (let i = 0; i < this._relations.length; ++i) {
            let rt = this._relations[i];
            this._view.addRelation(parent, rt);
            if (rt == fairygui.RelationType.Size) {
                this._view.setSize(parent.width, parent.height);
            }
            else if (rt == fairygui.RelationType.Center_Center) {
                var y = parent.height / 2 - obj.height / 2;
                obj.y = y;
            }
            else if (rt == fairygui.RelationType.Middle_Middle) {
                var x = parent.width / 2 - obj.width / 2;
                obj.x = x;
            }
        }
        parent.addChild(this._view);
        this.onCreated();
    }

    protected listenButtons(btnList, handler: Function) {
        for (let i = 0; i < btnList.length; ++i) {
            let btnName = btnList[i];
            this._view.getChild(btnName).asButton.onClick(this, handler, [btnName]);
        }
    }

    //开启界面更新。 （由于不是每一个界面都需要更新。所以，界面更新需要由子界面自己开启。)
    protected startUpdate(interval) {
        if (this._timer) {
            clearInterval(this._timer);
        }
        var self = this;
        this._timer = setInterval(function () {
            self.onUpdate();
        }, interval);
    }

    onCreated() { }
    onDispose() { }
    onUpdate() { }
}