import Handler = laya.utils.Handler;
import Loader = laya.net.Loader;

class MyAppSettings extends AppSettings {
    constructor() {
        super();
        var settings = this;
        settings.designWidth = 1280;//640;
        settings.designHeight = 720;
        settings.scaleMode = Laya.Stage.SCALE_FIXED_HEIGHT;
        settings.screenMode = Laya.Stage.SCREEN_VERTICAL;
        settings.showStats = true;
        settings.statsX = 0;
        settings.statsY = 500;
        settings.frameRate = Laya.Stage.FRAME_SLOW;
        settings.maxUILayer = UILayer.MAX_NUM;
        settings.alertWidget = GameAlert;
        settings.wcWidget = GameWC;
    }
}

// app entry.
class app {
    constructor() {
        var url = 'http://s1.babykylin.com'
        var url = 'http://localhost'
        // var url = 'http://118.178.178.152'
        //modules init
        HttpMgr.inst.configure(url, 9000);

        //initialize
        var settings = new MyAppSettings();
        bk.configure(settings);
        bk.start('preloading');
    }
}
new app();