/*
* httpMgr：统一管理HTTP请求
*/
class HttpMgr {
    private static _inst: HttpMgr = null;
    public static get inst(): HttpMgr {
        if (HttpMgr._inst == null) {
            HttpMgr._inst = new HttpMgr();
        }
        return HttpMgr._inst;
    }

    private addr: string = null;
    private port: number = null;
    private http: HTTP = null;
    constructor() {

    }

    configure(addr, port) {
        this.addr = addr;
        this.port = port;
        this.http = new HTTP(addr + ':' + port);
        console.log('服务器地址：', this.http)
    }

    get url() {
        return this.addr + ':' + this.port;
    }

    getSource() {
        return this.http;
    }

    getServerInfo(cb) {
        this.http.send('/get_serverinfo', null, cb);
    }

    guest(account, cb) {
        // this.http.send('/guest', { account: account, name: 'guest_' + (Date.now() % 10000) }, cb);
        this.http.send('/guest', { account: account, name: 'guest_' + account }, cb);
    }

    createRole(account, sign, name, cb) {
        var data = {
            account: account,
            sign: sign,
            name: name
        };
        this.http.send("/create_user", data, cb);
    }

    login(account, sign, cb) {
        this.http.send('/login', { account: account, sign: sign }, cb);
    }

    getUserCash(account, token, cb) {
        this.http.send('/get_user_cash', { account: account, token: token }, cb);
    }

    createPrivateRoom(data, cb) {
        this.http.send('/create_private_room', data, cb);
    }

    enterRoom(data, cb) {
        this.http.send('/enter_private_room', data, cb);
    }

    sendRequest(path, data, handler) {
        this.http.send(path, data, handler);
    }

}