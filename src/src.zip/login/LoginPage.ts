/*
* name;
*/
class LoginPage extends Page{
 //   private scene:LoginScene;

    constructor(){
        super('Login','PageLogin',UILayer.GAME);
//        this.scene = bk.sceneMgr.currentScene as LoginScene;
    }

    onCreated(){
        this._view.getChild('btn_guest').asButton.onClick(this,()=>{
            UserMgr.inst.doLoginAsGuest();
        });
    }
}