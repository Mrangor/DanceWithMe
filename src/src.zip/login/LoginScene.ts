/*
* name;
*/
class LoginScene extends Scene {
    constructor() {
        super(1280, 720);
    }

    getRes() {
        return [
            { url: "res/ui/Login.fui", type: Loader.BUFFER },
            { url: "res/ui/Login@atlas0.png", type: Loader.IMAGE },
            { url: "res/ui/Login@atlas_osvme.jpg", type: Loader.IMAGE },
            //{ url: "res/Lobby@atlas0.png", type: Loader.IMAGE }
        ];
    }

    start() {
        fairygui.UIPackage.addPackage('res/ui/Login');
        UIMgr.inst.add(LoginPage);
    }

    update() {

    }

    end() {
        super.end();
    }
}