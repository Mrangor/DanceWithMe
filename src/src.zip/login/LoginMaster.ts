class LoginMaster extends Master{
    
}