/*
* name;
*/
class GameWC extends WC{
    constructor(){
        super('Basic','Notice',UILayer.NOTICE);
    }
}