/*
* UI预设层级关系枚举
*/
enum UILayer {
    GAME,
    HUD,
    POPUP,
    ALERT,
    NOTICE,
    MAX_NUM,
}