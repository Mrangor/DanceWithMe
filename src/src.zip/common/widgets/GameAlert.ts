/*
* name;
*/
class GameAlert extends Alert{
    constructor(){
        super('Basic','Alert',UILayer.ALERT);
    }
}