class UI_PlayerInfoInGame extends Widget {
    private _userId: Number = -1;
    private isTenTimes: Boolean = true;//道具10连发
    private seatObj: Object = null;
    constructor() {
        super('Basic', 'UI_PlayerInfoInGame', UILayer.POPUP);
        this.keepCenter();
        this.initEventHandler();
    }

    onCreated() {
        let btnClose = this._view.getChild('btn_mask').asButton;
        btnClose.onClick(this, () => {
            this.hide();
            this.clear();
        });

        this.initDaoJu()
    }

    initEventHandler() {
        bk.on('init_user_info', this, this.initPlayerInfo)
    }

    clear() {
        bk.off('init_user_info', this, this.initPlayerInfo)
        this._userId = null;
        this.seatObj = null;
        this.isTenTimes = null;
    }
    initPlayerInfo(data: any) {
        console.log('用户Id:', data);
        let userId = data.userId
        if (!userId) {
            console.error('userId is null')
            return
        }
        this._userId = userId;
        this.isTenTimes = data.isTenTimes;
        this.seatObj = data.seatObj;

        let seatIndex = RoomMgr.inst.getSeatIndexByID(userId);
        var seat = RoomMgr.inst.getSeatByIdx(seatIndex);
        this._view.getChild('userId').asLabel.text = '用户ID：' + userId.toString();
        this._view.getChild('name').asLabel.text = '用户昵称：' + seat.name;
        this._view.getChild('level').asLabel.text = '等级：贫农2(Lv.2)';
        this._view.getChild('level2').asLabel.text = '贫农2';
        let total_score = `战绩：8胜/16负 33%`
        this._view.getChild('total_score').asLabel.text = total_score;

        var url = UserMgr.inst._info.imgUrl;
        url = HttpMgr.inst.url + '/image?url=' + encodeURIComponent(url) + '.jpg';
        this._view.getChild('icon').asLoader.url = url;
        this._view.getChild('daoju').visible = UserMgr.inst.userId != userId;
        this._view.getChild('n1').visible = false;
    }
    /**
     * 初始化道具
     */
    initDaoJu() {
        let daojuRoot = this._view.getChild('daoju').asCom;
        for (var index = 1; index < daojuRoot._children.length; index++) {
            var element = daojuRoot.getChild('n' + index);
            if (element) {
                element.asButton.onClick(this, this.onDaoJuItemClicked, ['n' + index]);
            }
        }
    }
    onDaoJuItemClicked(data) {
        console.log('道具发送目标用户：' + data, this._userId)
        let content = {
            target: this._userId,
            sender: UserMgr.inst.userId,
            daoju: data,
            isTenTimes: this.isTenTimes
        }
        bk.net.send('daoju', content);
        this.hide();
    }
}