/*
* name;
*/
class LayoutHallTitle {
    constructor(component: fairygui.GComponent) {
        component.getChild('name').asLabel.text = UserMgr.inst._info.name + ' ID:' + UserMgr.inst._info.userId;
        var url = UserMgr.inst._info.imgUrl;
        url = HttpMgr.inst.url + '/image?url=' + encodeURIComponent(url) + '.jpg';
        component.getChild('icon').asLoader.url = url;
        component.getChild('gems').asLabel.text = UserMgr.inst._info.gems.toString();

        component.getChild('icon').asButton.onClick(this, this.onBtnClicked, ['icon'])
    }

    onBtnClicked(sender) {
        console.log(`on ${sender} clicked`);
        Alert.show(`on ${sender} clicked`)
    }
}