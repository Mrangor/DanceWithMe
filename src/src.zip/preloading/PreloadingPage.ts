/*
* name;
*/
class PreloadingPage extends Page{
    private loadingBar:fairygui.GTextField = null;
    constructor(){
        super("Preloading","Preloading",UILayer.GAME);
    }
    
    onCreated(){
        this.loadingBar = this._view.getChild('loadingTxt').asTextField;
        this.setProgress(0);
    }

    setProgress(value:number){
        var progress = Math.floor(value*100);
        this.loadingBar.text = 'Loading... ' + progress + '%';
    }
}