class PreloadingMaster extends Master{
    
}