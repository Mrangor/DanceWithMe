/*
* name;
*/
class PreloadingScene extends Scene {
    private pageRoot: PreloadingPage = null;
    private loadingBar: any = null;

    constructor() {
        super(1280, 720);
    }

    start() {
        //预加载队列
        Laya.loader.load([
            { url: "res/ui/Preloading.fui", type: Loader.BUFFER }
        ], Handler.create(this, this.onPreloadingUILoaded));
    }

    update() {

    }

    end() {
        super.end();
    }

    onPreloadingUILoaded() {
        fairygui.UIPackage.addPackage('res/ui/Preloading');

        this.pageRoot = UIMgr.inst.add(PreloadingPage) as PreloadingPage;
        this.pageRoot.setProgress(0);

        this.startPreloadingQueue();
    }

    startPreloadingQueue() {
        //预加载队列
        Laya.loader.load([
            { url: "res/ui/Basic.fui", type: Loader.BUFFER },
            { url: "res/ui/Basic@atlas0.png", type: Loader.IMAGE },
            //{ url: "res/Lobby@atlas0.png", type: Loader.IMAGE }
        ], Handler.create(this, this.onLoaded), Handler.create(this, this.onProgress, null, false));

        //播放背景音乐
        Laya.SoundManager.playMusic('./music/bg.mp3');
    }

    onProgress(pro): void {
        this.pageRoot.setProgress(pro);
    }

    onLoaded(): void {
        fairygui.UIPackage.addPackage('res/ui/Basic');
        setTimeout(function () {
            MasterMgr.inst.switch('login');
        }.bind(this), 200);
    }
}