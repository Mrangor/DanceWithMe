/*
* 子游戏大厅页
*/
class LobbyPage extends Page{
    private cashRefresher:number = null;
    constructor(){
        super("Lobby", "PageLobby",UILayer.GAME);
    }

    onCreated(){
        new LayoutHallTitle(this._view.getChild('layout_hall_title').asCom);
        new LayoutBtns(this._view.getChild('layout_btns').asCom);

        var gameList = this._view.getChild('sub_game_list').asCom;
        for(var i = 0; i < gameList.numChildren; ++i){
            var child = gameList.getChildAt(i);
            var btn = child.asButton;
            if(btn != null){
                btn.onClick(this,this.onBtnClicked,[btn]);
            }
        }

            //加载真正的背景
            var url = './res/bg/lobby_platform_bg.jpg';
            Laya.loader.load(url,Handler.create(this,function(tex){
                this._view.getChild('bg').asLoader.onExternalLoadSuccess(tex);
            }));
    }

    onBtnClicked(sender:fairygui.GObject){
        if(sender.name == 'btn_enter_room'){
            UIMgr.inst.popup(UI_JoinGame);
        }
        else if(sender.name == 'btn_0010001'){
            MasterMgr.inst.switch('0010001');
        }
        else if(sender.name == 'btn_0030001'){
            MasterMgr.inst.switch('0030001');
        }
    }

    refreshCashes(){
        UserMgr.inst.refreshCashes(function(){
            this.txtGems.text = UserMgr.inst._info.gems.toString();
        }.bind(this));
    }

    onDispose(){
    }
}