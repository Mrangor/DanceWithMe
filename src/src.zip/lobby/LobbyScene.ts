/*
* 大厅场景类：
*/
class LobbyScene extends Scene {
    constructor() {
        super(1280, 720);
    }

    getRes() {
        return [
            { url: "res/ui/Lobby.fui", type: Loader.BUFFER },
            { url: "res/ui/Lobby@atlas0.png", type: Loader.IMAGE },
            // { url: "res/ui/Lobby@atlas_ti7515.jpg", type: Loader.IMAGE },
        ]
    }

    start() {
        fairygui.UIPackage.addPackage('res/ui/Lobby');
        UIMgr.inst.add(LobbyPage);
    }

    update() {

    }

    end() {
        super.end();
    }
}