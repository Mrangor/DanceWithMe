class LobbyMaster extends Master{
    
}